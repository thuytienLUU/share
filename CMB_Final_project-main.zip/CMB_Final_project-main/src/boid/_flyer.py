class Flyer:

    def move_flyer(self): ...

    def __init__(self) -> None:
        print("In Flyer")
